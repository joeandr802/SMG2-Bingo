Hello! Thanks for downloading this mod. 

In order to use it, you'll need working copies of Homebrew Launcher and Riivolution, 
as well as an SD card and a copy of Super Mario Galaxy 2 on disc.

Once you have those things, all you need to do is extract the zip folder you recieved
into the root of your SD Card, then make sure your SD card and game disc are in your Wii
when you launch Riivolution.

I changed a Luma in-game to say this, but I'll repeat it here:

Thank you for playing Super Mario Galaxy 2 Bingo!
This is my first SMG mod, so if you find any bugs, please let me know.
I'd also like to thank everyone who was involved in the creation and testing of this mod.
I couldn't have done it without your support.
Sincerely, ice_cream_joe

If you have any questions or run into any problems with the mod, please let me know.